function TCPClient(remoteID, localID)
    close all;
    warning off;
    set(0,'defaultfigurecolor','w');
    addpath ..\..\library
    addpath ..\..\library\matlab

    ip = '192.168.2.1';
    addpath BPSK\transmitter
    addpath BPSK\receiver

    PublicTxFreq = 2e9;
    PublicRxFreq = 1e9;

    global fileName
    fileName = 'NewFile';


    %% Transmit and Receive using MATLAB libiio

    % System Object Configuration
    s = iio_sys_obj_matlab; % MATLAB libiio Constructor
    s.ip_address = ip;
    s.dev_name = 'ad9361';
    s.in_ch_no = 2;
    s.out_ch_no = 2;
    s.in_ch_size = 42568;%length(txdata);
    s.out_ch_size = 42568.*8;%length(txdata).*8;

    s = s.setupImpl();

    input = cell(1, s.in_ch_no + length(s.iio_dev_cfg.cfg_ch));
    output = cell(1, s.out_ch_no + length(s.iio_dev_cfg.mon_ch));

    % Set the attributes of AD9361
    input{s.getInChannel('RX_LO_FREQ')} = PublicRxFreq;
    input{s.getInChannel('RX_SAMPLING_FREQ')} = 40e6;
    input{s.getInChannel('RX_RF_BANDWIDTH')} = 20e6;
    input{s.getInChannel('RX1_GAIN_MODE')} = 'manual';%% slow_attack manual
    input{s.getInChannel('RX1_GAIN')} = 10;
    % input{s.getInChannel('RX2_GAIN_MODE')} = 'slow_attack';
    % input{s.getInChannel('RX2_GAIN')} = 0;
    input{s.getInChannel('TX_LO_FREQ')} = PublicTxFreq;
    input{s.getInChannel('TX_SAMPLING_FREQ')} = 40e6;
    input{s.getInChannel('TX_RF_BANDWIDTH')} = 20e6;


    disp('start receiving...');
    %disp(['totoal packet count: ', int2str(length(sendArray))]);
    sendTime = clock;

    receivedStr = receiveDataByTCP(localID, remoteID, s, input, output, PublicTxFreq, PublicRxFreq);
    disp(receivedStr);
    file = matlab.net.base64decode(receivedStr);
    fid = fopen(['./','recv_', fileName], 'wb+');
    if fid>0
        fwrite(fid, file);
    end
    fclose(fid);

    rssi1 = output{s.getOutChannel('RX1_RSSI')};
    s.releaseImpl();
    clearvars -except times;
end

%% Funcution Area
% Send data by TCP protocol
% Data must shorter than or equal 47 bytes
function receivedStr = receiveDataByTCP(local, remote, s, input, output, currentTxFreq, currentRxFreq)
    head = struct('source',local,'remote',0,'SYN',0,'ACK',0,'FIN',0,'seq',0,'ack',0);
    %״̬��
    CLOSED = 0;
    SYN_SENT = 1;%��������
    LISTEN = 2;%����SYN
    SYN_RCVD = 3;%���յ�SYN
    ESTABLISHED = 4;%�ŵ�����
    FIN_WAIT1 = 5;%ֹͣ�ȴ�1
    FIN_WAIT2 = 6;%ֹͣ�ȴ�2
    CLOSE_WAIT = 7;%�رյȴ�
    LAST_ACK = 8;%���ȷ��
    TIME_WAIT = 9;%ʱ��ȴ�
    FIN_WAIT_1 = 10;
    TERMINATE = 11;

    status = CLOSED;
    messageStr = '';
    presentSeq = 10086;
    presentAck = 10086;
    status = CLOSED;
    receivedStr = '';
    alreadyReceivedIndex = 0;
    transportFinish = 0;
    isAckSent = false;
    global isOvertime
    isOvertime = false;
    global count
    count = 0;
    global fileName
    while status ~= TERMINATE
        switch status
            case CLOSED
                %����SYN����
                messageStr = GenerateTCPHead(local, remote, 1, 0, 0, presentSeq, presentAck);
                sendMessage(s,messageStr,input);
                status = SYN_SENT;
                t = timer('TimerFcn',@t_TimerFcnOvertime,'StartDelay', 5);
                start(t)
            case SYN_SENT
                count = 0;
                isReciveAck = 0;
                %����ACK�ź�
                while isReciveAck == 0 
                    output = readRxData(s);
                    I = output{1};
                    Q = output{2};
                    Rx = I+1i*Q;
                    [rStr, crcResult] = bpsk_rx_func(Rx);
                    if crcResult == 1
                        %������ͷ
                        head = decodeHead(head,rStr);
                        if head.remote == local
                            if head.SYN == 1 && head.ACK == 1 && head.ack == presentSeq + 1
                                presentSeq = presentSeq + 1;
                                presentAck = head.seq + 1;
                                messageStr = GenerateTCPHead(local, head.source, 0, 1, 0, presentSeq, presentAck);
                                isReciveAck = 1;
                            end
                        end
                    end
                    if getIsOvertime() == true
                        messageStr = GenerateTCPHead(local, remote, 1, 0, 0, presentSeq, presentAck);
                        sendMessage(s,messageStr,input);
                        disp(['Resent SYN']);
                        setIsOvertime(false);
                        delete(timerfind)
                        t = timer('TimerFcn',@t_TimerFcnOvertime,'StartDelay', 5);
                        start(t)
                    end
                end
                % Handshake step III
                hsIII = 0;
                while hsIII < 5
                    sendMessage(s,messageStr,input);
                    pause(0.1)
                    hsIII = hsIII + 1;
                end
                status = ESTABLISHED;
                disp('Connection established')
            case ESTABLISHED
                t = timer('TimerFcn',@t_TimerFcnOvertime,'StartDelay', 5);
                if transportFinish == 1
                    status = FIN_WAIT_1;
                else
                    %����һ����Ϣ
                    output = readRxData(s);
                    I = output{1};
                    Q = output{2};
                    Rx = I+1i*Q;
                    [rStr, crcResult] = bpsk_rx_func(Rx);
                    if crcResult == 1
                        head = decodeHead(head,rStr);
                        %���յ���ǰ��Ҫ�İ�
                        if head.remote == local && head.SYN == 0 && head.ACK == 0 && head.FIN == 0 && head.seq == alreadyReceivedIndex + 1
                            tmp = char(rStr(14:length(rStr)))
                            tmp = deblank(tmp);
                            receivedStr = [receivedStr, char(rStr(14:length(rStr)))];
                            alreadyReceivedIndex = alreadyReceivedIndex + 1;
                            isAckSent = false;
                            setIsOvertime(false);
                        else
                            if head.FIN == 1
                                status = FIN_WAIT_1;
                                tmp = char(rStr(14:length(rStr)))
                                tmp = deblank(tmp);
                                fileName = tmp;
                            end
                        end
                        disp(['already received ',num2str(alreadyReceivedIndex)]);
                    end

                    if getIsOvertime() == true
                        sendMessage(s,GenerateTCPHead(local,remote,0,1,0,head.seq,alreadyReceivedIndex),input);
                        disp(['Package ack time overtime, Index:', num2str(alreadyReceivedIndex)])
                        start(t);
                        setIsOvertime(false);
                    end
                    if isAckSent == false
                        %����һ��ACK��Ϣ����
                        disp(['Sent ACK,','Index;',num2str(alreadyReceivedIndex)]);
                        sendMessage(s,GenerateTCPHead(local,remote,0,1,0,head.seq,alreadyReceivedIndex),input);
                        isAckSent = true;
                        setIsOvertime(false);
                        delete(timerfind)
                        t = timer('TimerFcn',@t_TimerFcnOvertime,'StartDelay', 5);
                        start(t);
                    end
                end

            case FIN_WAIT_1
                disp('status close_wait');
                %�����������FIN��Ϣ
                sendMessage(s,GenerateTCPHead(local,remote,0,0,1,unidrnd(100000),unidrnd(100000)),input);
                %���ܷ��������ص���Ϣ
                output = readRxData(s);
                I = output{1};
                Q = output{2};
                Rx = I+1i*Q;
                [rStr, crcResult] = bpsk_rx_func(Rx);
                if crcResult == 1
                    head = decodeHead(head,rStr);
                    if head.remote == local && head.SYN == 0 && head.ACK == 1 && head.FIN == 1
                        status = TIME_WAIT;
                    end
                end
            case TIME_WAIT
                disp('status time_wait');
                finHead = GenerateTCPHead(local,remote,0,1,0,unidrnd(100000),unidrnd(100000));
                %����10�λ�����Ϣ
                for times = 1:10
                    sendMessage(s,finHead,input);
                end
                status = TERMINATE;
                
            case TERMINATE
                input{s.getInChannel('RX_LO_FREQ')} = currentTxFreq;
                input{s.getInChannel('TX_LO_FREQ')} = currentRxFreq;
        end
    end
end

function headStr = GenerateTCPHead(local, remote, SYN, ACK, FIN, seq, ack)
    tmpHead = struct('source',local,'remote',remote,'SYN',SYN,'ACK',ACK,'FIN',FIN,'seq',seq,'ack',ack);
    headStr = getTCPHeadStr(tmpHead);
end

%��4B��������ת����4��char�ַ�
function str = get4BStr(num)
    str = [char(bitand(uint32(num),uint32(hex2dec('ff000000')))/uint32(hex2dec('1000000'))),char(bitand(uint32(num),uint32(hex2dec('00ff0000')))/uint32(hex2dec('10000'))),char(bitand(uint32(num),uint32(hex2dec('0000ff00')))/uint32(hex2dec('100'))),char(bitand(uint32(num),uint32(hex2dec('000000ff'))))];
end

%��1B��������ת����char�ַ�
function str = get1BStr(num)
    str = char(num);
end

%��ȡȷ��λ
function str = getTagStr(SYN,ACK,FIN)
    str = char(bitshift(uint8(SYN),2) + bitshift(uint8(ACK),1) + uint8(FIN) + uint8(8));
end

%����13B����TCP��ͷ
function str = getTCPHeadStr(head)
    str = ['MG',get1BStr(head.source),get1BStr(head.remote),getTagStr(head.SYN,head.ACK,head.FIN),get4BStr(head.seq),get4BStr(head.ack)];
end

%������ͷ
function mhead = decodeHead(mhead,messageStr)
    mhead.source = abs(messageStr(3));
    mhead.remote = abs(messageStr(4));
    mhead.SYN = 0;
    mhead.ACK = 0;
    mhead.FIN = 0;
    if bitand(uint8(abs(messageStr(5))),uint8(4)) > 0
        mhead.SYN = 1;
    end
    if bitand(uint8(abs(messageStr(5))),uint8(2)) > 0
        mhead.ACK = 1;
    end
    if bitand(uint8(abs(messageStr(5))),uint8(1)) > 0
        mhead.FIN = 1;
    end
    mhead.seq = abs(messageStr(6))*uint32(hex2dec('1000000')) + abs(messageStr(7))*uint32(hex2dec('10000')) + abs(messageStr(8))*uint32(hex2dec('100')) + abs(messageStr(9));
    mhead.ack = abs(messageStr(10))*uint32(hex2dec('1000000')) + abs(messageStr(11))*uint32(hex2dec('10000')) + abs(messageStr(12))*uint32(hex2dec('100')) + abs(messageStr(13));
    
end

%����һ�α���
function sendMessage(s,str,input)
    txdata = bpsk_tx_func(str);
    txdata = round(txdata .* 2^14);
    txdata = repmat(txdata,8,1);
    input{1} = real(txdata);
    input{2} = imag(txdata);
    disp(['Sent count:', num2str(getCount)])
    setCount(getCount + 1)
    writeTxData(s, input); %��������
end

function setIsOvertime(val)
    global isOvertime
    isOvertime = val;
end

function val = getIsOvertime()
    global isOvertime
    val = isOvertime;
end

function setCount(val)
    global count
    count = val;
end

function val = getCount()
    global count
    val = count;
end

function t_TimerFcnOvertime(hObject,eventdata)
    setIsOvertime(true)
end
