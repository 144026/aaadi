function TCPServer(localID, filePath, fileName)

    warning off;
    set(0,'defaultfigurecolor','w');
    addpath ..\..\library
    addpath ..\..\library\matlab
    
    ip = '192.168.2.1';
    addpath BPSK\transmitter
    addpath BPSK\receiver
    
    
    %% Transmit and Receive using MATLAB libiio
    
    % System Object Configuration
    s = iio_sys_obj_matlab; % MATLAB libiio Constructor
    s.ip_address = ip;
    s.dev_name = 'ad9361';
    s.in_ch_no = 2;
    s.out_ch_no = 2;
    s.in_ch_size = 42568;%length(txdata);
    s.out_ch_size = 42568.*8;%length(txdata).*8;
    
    s = s.setupImpl();
    
    input = cell(1, s.in_ch_no + length(s.iio_dev_cfg.cfg_ch));
    output = cell(1, s.out_ch_no + length(s.iio_dev_cfg.mon_ch));
    
    % Set the attributes of AD9361
    input{s.getInChannel('RX_LO_FREQ')} = 2e9;
    input{s.getInChannel('RX_SAMPLING_FREQ')} = 40e6;
    input{s.getInChannel('RX_RF_BANDWIDTH')} = 20e6;
    input{s.getInChannel('RX1_GAIN_MODE')} = 'manual';%% slow_attack manual
    input{s.getInChannel('RX1_GAIN')} = 10;
    % input{s.getInChannel('RX2_GAIN_MODE')} = 'slow_attack';
    % input{s.getInChannel('RX2_GAIN')} = 0;
    input{s.getInChannel('TX_LO_FREQ')} = 1e9;
    input{s.getInChannel('TX_SAMPLING_FREQ')} = 40e6;
    input{s.getInChannel('TX_RF_BANDWIDTH')} = 20e6;
    
    %�ļ�������Ϣ��װ
    fid = fopen(filePath,'rb');
    bytes = fread(fid);
    fclose(fid);
    encoder = org.apache.commons.codec.binary.Base64;
    strToSend = char(encoder.encode(bytes));
    strToSend = strToSend';
    
    arrLength = ceil(length(strToSend)/47);
    sendArray = cell(1,arrLength);
    for index = 1:arrLength
        if index * 47 > length(strToSend)
            sendArray(index) = {strToSend(index*47-46:length(strToSend))};
        else
            sendArray(index) = {strToSend(index*47-46:index*47)};
        end
    end
    
    disp(['total packages:',num2str(arrLength)]);
    
    %TCP��ͷ��װ
    %2B 'MG'
    %1B Դ��ַ
    %1B Ŀ�ĵ�ַ
    %1B ȷ��λ��SYN(b7)|ACK(b6)|FIN(b5)|reserve
    %4B ���к� seq
    %4B ack
    messageHeadStr = 'MG';
    head.source = 1;
    head.remote = 2;
    head.SYN = 0;
    head.ACK = 0;
    head.FIN = 0;
    head.seq = 0;
    head.ack = 0;
    disp('start Reciving...');
    SendDataByTCP(localID, s, input, output, sendArray, arrLength, fileName)
    sendTime = clock;
    
    disp('transport finished');
    
    rssi1 = output{s.getOutChannel('RX1_RSSI')};
    s.releaseImpl();
    
    clearvars -except times;
    end
    
    %% Functions Area
    
    function SendDataByTCP(local, s, input, output, sendArray, arrLength, filename)
        %��ͷ�ṹ��
        head = struct('source',local,'remote',0,'SYN',0,'ACK',0,'FIN',0,'seq',0,'ack',0);
        msgHeadStr = '';
        %״̬��
        CLEARSTORE = 0;%����豸����
        SYN_SENT = 1;%��������
        LISTEN = 2;%����SYN
        SYN_RCVD = 3;%���յ�SYN
        ESTABLISHED = 4;%�ŵ�����
        FIN_WAIT1 = 5;%ֹͣ�ȴ�1
        FIN_WAIT2 = 6;%ֹͣ�ȴ�2
        CLOSE_WAIT = 7;%�رյȴ�
        LAST_ACK = 8;%���ȷ��
        TIME_WAIT = 9;%ʱ��ȴ�
        TIME_OUT = 10;%���䳬ʱ
        TERMINATE = 11;%�������
        
    
        status = CLEARSTORE;
        messageStr = '0';
        presentSeq = 10086;
        presentAck = 0;
        remote = 0;
        
        isSentFIN = false;
    
        global isOvertime
        isOvertime = false;
        
        global count
        count = 0;
        
        FINCount = 0;
    
        while status ~= TERMINATE
            %pause(0.5);
            %disp('start loop');
            switch status
                case CLEARSTORE
                    for times = 1:10
                        sendMessage(s,GenerateTCPHead(local,remote,0,0,0,unidrnd(100000),unidrnd(100000)),input);
                    end
                    status = LISTEN;                
                case LISTEN
                    %����Ƿ��յ�SYN
                    disp('in status:LISTEN');
                    output = readRxData(s);
                    I = output{1};
                    Q = output{2};
                    Rx = I+1i*Q;
                    [rStr, crcResult] = bpsk_rx_func(Rx);
                    if crcResult == 1
                        %������ͷ
                        head = decodeHead(head, rStr);
                        if head.remote == local
                            if head.SYN == 1
                                status = SYN_RCVD;
                                %SYN=1��ACK=1��seq=arrLength��ack=head.seq+1�����ɰ�ͷ
                                presentAck = head.seq + 1;
                                messageStr = GenerateTCPHead(local, head.source,1, 1, 0, presentSeq, presentAck);
                            end
                        end
                    end
                case SYN_RCVD
                    disp('in status SYN_RCVD');
                    %����ACK��Ϣ
                    sendMessage(s,messageStr,input);
                    %�������ص�ACK��Ϣ
                    output = readRxData(s);
                    I = output{1};
                    Q = output{2};
                    Rx = I+1i*Q;
                    [rStr, crcResult] = bpsk_rx_func(Rx);
                    if crcResult == 1
                        %������ͷ
                        head = decodeHead(head,rStr);
                        if head.remote == local
                            if head.ACK == 1 && head.seq == presentAck && head.ack == presentSeq + 1
                                %�ŵ�����
                                status = ESTABLISHED;
                                remote = head.source;
                            end
                        end
                    end
                case ESTABLISHED
                    %��������
                    alreadyArrivedIndex = 0;
                    isPackageSent = false;
                    t = timer('TimerFcn',@t_TimerFcnOvertime,'StartDelay', 5);
                    while alreadyArrivedIndex < arrLength
                        %����һ�����ݰ�
                        if isPackageSent == false || getIsOvertime() == true
                            if getIsOvertime() == true
                                disp(['Its overtime, package', num2str(alreadyArrivedIndex+1)])
                                setIsOvertime(false);
                            end
                            presentSentHead = GenerateTCPHead(local,remote,0,0,0,alreadyArrivedIndex+1,10086);
                            dataSeag = char(sendArray(alreadyArrivedIndex+1));
                            tmp = uint8(presentSentHead);
                            sendTmp = [presentSentHead, dataSeag];
                            disp(sendTmp);
                            sendMessage(s,sendTmp,input);
                            isPackageSent = true;
                            delete(timerfind)
                            t = timer('TimerFcn',@t_TimerFcnOvertime,'StartDelay', 5);
                            start(t)
                        end
                        %��ȡACK���жϿͻ����Ƿ���ȡ��
                        output = readRxData(s);
                        I = output{1};
                        Q = output{2};
                        Rx = I+1i*Q;
                        [rStr, crcResult] = bpsk_rx_func(Rx);
                        if crcResult == 1
                            head = decodeHead(head,rStr);
                            %�����յ�����һ����
                            if head.remote == local && head.SYN == 0 && head.ACK == 1 && head.FIN == 0 && head.ack == alreadyArrivedIndex+1
                                alreadyArrivedIndex = alreadyArrivedIndex + 1;
                                isPackageSent = false;
                                setIsOvertime(false)
                            end
                        end
                        disp(['already arrived ',num2str(alreadyArrivedIndex)]);
                    end
                
                    status = FIN_WAIT1;
                    
                case FIN_WAIT1
                    disp('transport finish,status:fin_wait_1');
                    %����FIN��Ϣ
                    if isSentFIN == false
                        sendMessage(s,[GenerateTCPHead(local,remote,0,1,1,unidrnd(100000),unidrnd(100000)),filename],input);
                        t = timer('TimerFcn',@t_TimerFcnOvertime,'StartDelay', 5);
                        isSentFIN = true;
                        start(t)
                    end
                    
                    if getIsOvertime == true
                        delete(timerfind)
                        t = timer('TimerFcn',@t_TimerFcnOvertime,'StartDelay', 5);
                        sendMessage(s,[GenerateTCPHead(local,remote,0,1,1,unidrnd(100000),unidrnd(100000)),filename],input);
                        FINCount = FINCount + 1;
                        start(t)
                    end
                    
                    %���տͻ��˷��͵���Ϣ
                    output = readRxData(s);
                    I = output{1};
                    Q = output{2};
                    Rx = I+1i*Q;
                    [rStr, crcResult] = bpsk_rx_func(Rx);
                    if crcResult == 1
                        head = decodeHead(head,rStr);
                        if head.remote == local && head.SYN == 0 && head.ACK == 0 && head.FIN == 1
                            status = CLOSE_WAIT;
                        end
                    end
                    
                    if FINCount >= 5
                        status = CLOSE_WAIT;
                    end
                case CLOSE_WAIT
                   disp('status close_wait');
                   %����10��ACK��Ϣ
                   presentSentHead = GenerateTCPHead(local,remote,0,1,1,unidrnd(100000),unidrnd(100000));
                   for time = 1:10
                       sendMessage(s,presentSentHead,input);
                   end
                   status = TIME_WAIT;
                case TIME_WAIT
                    %�ȴ�����ACK��Ϣ
                    output = readRxData(s);
                    I = output{1};
                    Q = output{2};
                    Rx = I+1i*Q;
                    [rStr, crcResult] = bpsk_rx_func(Rx);
                    if crcResult == 1
                        head = decodeHead(head,rStr);
                        if head.remote == local && head.SYN == 0 && head.ACK == 1 && head.FIN == 0
                            status = CLEARSTORE;
                        end
                    end
            end
        end
end

%��4B��������ת����4��char�ַ�
%����ÿ�ֽڶ���33��ʼ������ASCII���Ʒ���
function str = get4BStr(num)
    str = [char(bitand(uint32(num),uint32(hex2dec('ff000000')))/uint32(hex2dec('1000000'))),char(bitand(uint32(num),uint32(hex2dec('00ff0000')))/uint32(hex2dec('10000'))),char(bitand(uint32(num),uint32(hex2dec('0000ff00')))/uint32(hex2dec('100'))),char(bitand(uint32(num),uint32(hex2dec('000000ff'))))];
end

%��1B��������ת����char�ַ�
function str = get1BStr(num)
    str = char(num);
end

%��ȡȷ��λ,00100/SYN/ACK/FIN
function str = getTagStr(SYN,ACK,FIN)
    str = char(bitshift(uint8(SYN),2) + bitshift(uint8(ACK),1) + uint8(FIN) + uint8(32));
end

%����13B����TCP��ͷ
function str = getTCPHeadStr(head)
    str = ['MG',get1BStr(head.source),get1BStr(head.remote),getTagStr(head.SYN,head.ACK,head.FIN),get4BStr(head.seq),get4BStr(head.ack)];
end

%������ͷ
function mhead = decodeHead(mhead,messageStr)
    if length(messageStr) >= 13
        mhead.source = abs(messageStr(3));
        mhead.remote = abs(messageStr(4));
        mhead.SYN = 0;
        mhead.ACK = 0;
        mhead.FIN = 0;
        if bitand(uint8(abs(messageStr(5))),uint8(4)) > 0
            mhead.SYN = 1;
        end
        if bitand(uint8(abs(messageStr(5))),uint8(2)) > 0
            mhead.ACK = 1;
        end
        if bitand(uint8(abs(messageStr(5))),uint8(1)) > 0
            mhead.FIN = 1;
        end
        mhead.seq = abs(messageStr(6))*uint32(hex2dec('1000000')) + abs(messageStr(7))*uint32(hex2dec('10000')) + abs(messageStr(8))*uint32(hex2dec('100')) + abs(messageStr(9));
        mhead.ack = abs(messageStr(10))*uint32(hex2dec('1000000')) + abs(messageStr(11))*uint32(hex2dec('10000')) + abs(messageStr(12))*uint32(hex2dec('100')) + abs(messageStr(13));
    else
        disp('illegal length');
    end
end

%����һ�α���
function sendMessage(s,str,input)
    txdata = bpsk_tx_func(str);
    txdata = round(txdata .* 2^14);
    txdata = repmat(txdata,8,1);
    input{1} = real(txdata);
    input{2} = imag(txdata);
    disp(['Sent count:', num2str(getCount)]);
    setCount(getCount + 1);
    writeTxData(s, input); %��������
    %pause(1);
end

function headStr = GenerateTCPHead(local, remote, SYN, ACK, FIN, seq, ack)
    tmpHead = struct('source',local,'remote',remote,'SYN',SYN,'ACK',ACK,'FIN',FIN,'seq',seq,'ack',ack);
    headStr = getTCPHeadStr(tmpHead);
end

function setIsOvertime(val)
    global isOvertime
    isOvertime = val;
end

function val = getIsOvertime()
    global isOvertime
    val = isOvertime;
end

function setCount(val)
    global count
    count = val;
end

function val = getCount()
    global count
    val = count;
end

function t_TimerFcnOvertime(hObject,eventdata)
    setIsOvertime(true)
end

