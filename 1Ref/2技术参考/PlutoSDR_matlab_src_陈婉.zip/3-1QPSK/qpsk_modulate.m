function mod_symbols=qpsk_modulate(mst_bits)
full_len=length(mst_bits);
table=exp(j*[-3/4*pi 3/4*pi 1/4*pi -1/4*pi]);  % generates QPSK symbols
table=table([0 1 3 2]+1); % Gray code mapping pattern for QPSK symbols
inp=reshape(mst_bits,2,full_len/2);
mod_symbols=table([2 1]*inp+1);  % maps transmitted bitBIs into QPSK symbols
mod_symbols=mod_symbols.*sqrt(2);
end