function soft_bits = qpsk_demodulate(rx_symbols)
soft_bits = zeros(2,length(rx_symbols));
bit0 = real(rx_symbols);
bit0 = (sign(bit0)+1)/2;
bit1 = imag(rx_symbols);
bit1 = (sign(bit1)+1)/2;
soft_bits(1,:) = bit0;
soft_bits(2,:) = bit1;
soft_bits = soft_bits(:)';
end

