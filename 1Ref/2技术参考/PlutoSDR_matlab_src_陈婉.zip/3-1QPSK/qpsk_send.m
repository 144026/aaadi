function txdata = qpsk_send(msgStr)
seq_sync = qpsk_gen_m_seq([1 0 0 0 0 0 1]);
seq_sync = [0,seq_sync];
seq_symbols = qpsk_modulate(seq_sync);
mst_bits = qpsk_str_bits(msgStr);
mod_symbols = qpsk_modulate(mst_bits);
data_symbols = [seq_symbols mod_symbols];
fir = 1/2*ones(1,4);
tx_frame = upfirdn(data_symbols,fir,4);
data_symbols = [tx_frame,zeros(1,1e3)];
data_symbols = data_symbols.';
txdata = round(data_symbols .* 2^14);
txdata = repmat(txdata, 8,1);
end

