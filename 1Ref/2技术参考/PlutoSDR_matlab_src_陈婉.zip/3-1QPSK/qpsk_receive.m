function soft_bits = qpsk_receive( dataall )
seq_sync = qpsk_gen_m_seq([1 0 0 0 0 0 1]);
seq_sync = [0,seq_sync];
seq_symbols = qpsk_modulate(seq_sync);
fir = 1/2*ones(1,4);
rx_sig_filter = upfirdn(dataall,fir,1);
c1=max([abs(real(rx_sig_filter)),abs(imag(rx_sig_filter))]);
rx_sig_down=rx_sig_filter./c1;
rx_sig_down=qpsk_timing_recovery(rx_sig_down.');
index_s = framesyn(rx_sig_down,seq_symbols);
index_e=index_s+304-1;
rx_sig_down = rx_sig_down(index_s:index_e);
out_signal = pcorrect(rx_sig_down,seq_symbols);
rx_symbols= out_signal(64+1:end);
soft_bits = qpsk_demodulate(rx_symbols);
end

