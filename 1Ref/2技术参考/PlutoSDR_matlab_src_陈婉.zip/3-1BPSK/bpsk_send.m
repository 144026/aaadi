function txdata = bpsk_send(msgStr)
seq_sync = gen_m_seq([1 0 0 0 0 0 1]);
seq_symbols = bpsk_modulate(seq_sync);
mst_bits = str_bits(msgStr);
mod_symbols = bpsk_modulate(mst_bits);
data_symbols = [seq_symbols mod_symbols];
fir = 1/2*ones(1,4);
data_symbols = upfirdn(data_symbols,fir,4);
data_symbols = [data_symbols,zeros(1,2e3)];
data_symbols = data_symbols.';
txdata = round(data_symbols .* 2^14);
txdata=repmat(txdata, 8,1);
end

