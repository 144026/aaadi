function mod_symbols=bpsk_modulate(mst_bits)
   table=exp(1i*[0 -pi]);  % generates BPSK symbols
   table=table([1 0]+1); % Gray code mapping pattern for BPSK symbols
   inp=mst_bits;
   mod_symbols=table(inp+1);
end