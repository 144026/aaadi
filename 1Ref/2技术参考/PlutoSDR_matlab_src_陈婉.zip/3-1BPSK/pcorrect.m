function out_signal = pcorrect(rx_sig_down,seq_symbols)
len=length(seq_symbols);
L=len;
for i=1:L
    cor(i)=rx_sig_down(i).*conj(seq_symbols(i));
end
ang=angle(mean(cor));
out_signal=rx_sig_down.*exp(-1i*ang);
end

