function index_s = framesyn(rx_sig_down,seq_symbols)
signali=(real(rx_sig_down)>0)*2-1;
signalq=(imag(rx_sig_down)>0)*2-1;
signalo=signali+1i*signalq;
L=length(signali);
N=length(seq_symbols);
for i=N:L
    cor_abs(i)=abs(signalo(i-N+1:i)*seq_symbols');
end
[~,bo]=max(cor_abs(1:length(cor_abs)/2));
index_s=bo-N+1;
end

