function soft_bits = bpsk_demodulate(rx_symbols)
soft_bits = real(rx_symbols);
soft_bits = (sign(soft_bits)+1)/2;
end

