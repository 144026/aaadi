function mod_symbols=msk_modulate(mst_bits)
PN = length(mst_bits);
fs = 4;
T = 1;
t = 0:1/fs:T*PN-1/fs;
a = 2*mst_bits-1;
fi = -pi/2*cumsum([ 0 diff(a).*(1:PN-1) ]);
p = cos(fi);
q = a.*p;
pp = kron(p,ones(1,fs*T));
qq = kron(q,ones(1,fs*T));
c_cos = cos(pi*t/(2*T)); 
c_sin = sin(pi*t/(2*T));  
mod_symbols = pp.*c_cos+1i*qq.*c_sin;
end