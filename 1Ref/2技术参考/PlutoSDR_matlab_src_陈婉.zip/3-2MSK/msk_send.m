function txdata = msk_send(msgStr)
seq_sync = msk_gen_m_seq([1 0 0 0 0 0 1]);
seq_symbols = msk_modulate(seq_sync);
mst_bits = msk_str_bits(msgStr);
mst_symbols = msk_modulate(mst_bits);
data_symbols = [seq_symbols mst_symbols];
data_symbols = [data_symbols,zeros(1,1e3)];
data_symbols = data_symbols.';
txdata = round(data_symbols .* 2^14);
txdata = repmat(txdata, 8,1);
end

