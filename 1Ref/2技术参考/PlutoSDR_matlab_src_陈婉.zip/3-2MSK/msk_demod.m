function soft_bits=msk_demod(rx_symbols)
PN = length(rx_symbols)/4;
fs = 4;
T = 1;
t = 0:1/fs:T*PN-1/fs;
c_cos = cos(pi*t/(2*T)); 
c_sin = sin(pi*t/(2*T));
sig1 = rx_symbols.*c_cos;
sig2 = 1i*rx_symbols.*c_sin;
for k = 1:PN-1
    if mod(k,2) == 0
        p0 = sum(sig1((k-1)*fs*T+1:(k+1)*fs*T));
    else
        p0 = -sum(sig2((k-1)*fs*T+1:(k+1)*fs*T));
    end
    if p0 > 0
        code1(k) = 1;
    else
        code1(k) = -1;
    end
end
for k = PN
    if mod(k,2) == 0
        p0 = sum(sig1((k-1)*fs*T+1:k*fs*T));
    else
        p0 = -sum(sig2((k-1)*fs*T+1:k*fs*T));
    end
    if p0 > 0
        code1(k) = 1;
    else
        code1(k) = -1;
    end
end
for k = 1:PN
    if k == 1
        a2(k) = code1(k);
    else
        a2(k) = code1(k-1) * code1(k);
    end
end
soft_bits = (a2+1)/2;
end