function soft_bits = msk_receive(dataall)
seq_sync = msk_gen_m_seq([1 0 0 0 0 0 1]);
seq_symbols = msk_modulate(seq_sync);
rx_sig_filter = dataall;
c1 = max([abs(real(rx_sig_filter)),abs(imag(rx_sig_filter))]);
rx_sig_down = rx_sig_filter./c1;
index_s = framesyn(rx_sig_down,seq_symbols);
index_e = index_s+2428-1;
rx_sig_down = rx_sig_down(index_s:index_e);
out_signal = pcorrect(rx_sig_down,seq_symbols);
rx_symbols = out_signal(508+1:end);
soft_bits = msk_demod(rx_symbols);
end

