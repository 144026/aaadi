clearvars -except times;close all;warning off;

addpath library
addpath library\matlab

ip = '192.168.2.1';
Fc = 2e9;
Fs = 40e6;                  
B = Fs/2;
Gain = 10;
m = 0;
%ѧ����д����ʵ�ֻ����ź�txdata
msgStr=[
    'a----------h---a',...
    '-b-----s------b-',...
    '--c----------c--',...
    '---d---d----',...
    ];
txdata = msk_send(msgStr);
%% Transmit and Receive using MATLAB libiio
% System Object Configuration
s = iio_sys_obj_matlab; % MATLAB libiio Constructor
s.ip_address = ip;
s.dev_name = 'ad9361';
s.in_ch_no = 2;
s.out_ch_no = 2;
s.in_ch_size = length(txdata);
s.out_ch_size = length(txdata);

s = s.setupImpl();

input = cell(1, s.in_ch_no + length(s.iio_dev_cfg.cfg_ch));
output = cell(1, s.out_ch_no + length(s.iio_dev_cfg.mon_ch));

% Set the attributes of AD9361
input{s.getInChannel('RX_LO_FREQ')} = Fc;
input{s.getInChannel('RX_SAMPLING_FREQ')} = Fs;
input{s.getInChannel('RX_RF_BANDWIDTH')} = B;
input{s.getInChannel('RX1_GAIN_MODE')} = 'manual';
input{s.getInChannel('RX1_GAIN')} = Gain;
input{s.getInChannel('TX_LO_FREQ')} = Fc;
input{s.getInChannel('TX_SAMPLING_FREQ')} = Fs;
input{s.getInChannel('TX_RF_BANDWIDTH')} = B;

while(1)
    fprintf('Transmitting Data Block %i ...\n',m);
    input{1} = real(txdata);
    input{2} = imag(txdata);
    output = stepImpl(s, input);
    m = m+1;
    pause(0.5);
end
fprintf('Transmission and reception finished\n');
rssi = output{s.getOutChannel('RX1_RSSI')};
s.releaseImpl();